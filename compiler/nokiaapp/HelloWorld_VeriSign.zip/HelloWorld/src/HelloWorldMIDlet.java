/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

/**
 * @author jarmlaht
 */
public class HelloWorldMIDlet extends MIDlet implements CommandListener {
    private Form form;
    private Command exitCommand;
    
    public void startApp() {
        form = new Form("HelloWorldMIDlet");
        exitCommand = new Command("Exit", Command.EXIT, 1);
        form.setCommandListener(this);
        form.addCommand(exitCommand);
        Display.getDisplay(this).setCurrent(form);
    }

    public void pauseApp() {
    }

    public void destroyApp(boolean unconditional) {
    }

    public void commandAction(Command c, Displayable d) {
        if (c == exitCommand) this.notifyDestroyed();
    }
}
